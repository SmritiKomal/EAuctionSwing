package auction;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class MyCart extends JFrame implements ActionListener{
    JLabel label;
    JButton homeButton;
    JFrame frame;
    String custID,item,itemid;
    public MyCart(String  itemID, String  itemType,String CustomerID){
        frame=new JFrame();
        custID=CustomerID;
        itemid=itemID;
        item=itemType;
        
        frame.setTitle("My Cart");
        
        label = new JLabel("My Cart");
        label.setForeground(Color.blue);
        label.setFont(new Font("Serif", Font.BOLD, 40));
        Font font=new Font("Serif",Font.BOLD,28);
        //TODO : change this path for yourself
        ImageIcon iconHome = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\homeIcon.png");
        homeButton=new JButton(iconHome);
        
        homeButton.addActionListener(this);
        
        frame.add(label);
        frame.add(homeButton);
        
        frame.setSize(2000, 2000);
        frame.setLayout(null);
        frame.setVisible(true);
        
        homeButton.setVisible(true);
        
        label.setBounds(700,80,600,50);
        homeButton.setBounds(200,150,150,50);
    }
    public void actionPerformed(ActionEvent event){
        
        if(event.getSource()== homeButton){
            new customer(custID).setVisible(true);
            frame.setVisible(false);
        }
           
    }
    public static void main(String args[]){
        new MyCart(args[0]);
    }
}
