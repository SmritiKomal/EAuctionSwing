package auction;
import static auction.Registration.vendorID;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.DateFormat;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class ItemDetail extends JFrame implements ActionListener
{
    JLabel label,sourceLabel, weightLabel, ageLabel, uploadPictureLabel, l5, l6, l7, l8, l9, l10;
    static JTextField tf1, tf2, tf3,tf5, tf7, tf10, tf9, tf8;
    String  itemnm,venid="",biddernm,brand,model,source,a="",b="",strtd,s,s1,s2,s3,s4,s5,endd;
    int initamt,currbid,age,wt,workC, x=0; 
   // public String itemid;
    JButton submitButton, clearButton,startDateButton, endDateButton, uploadPictureButton, uploadDocumentButton, homeButton;
    JFrame frame=new JFrame();
    JRadioButton jewelleryRadioButton,carsRadioButton,watchRadioButton;
    JRadioButton yesButton,noButton;
    ButtonGroup bg,bg1;
    Random ran = new Random();
    int first4 = (ran.nextInt() % 9000) + 1000;
    int first = Math.abs(first4);
    public static String pic="",doc="",itemid="",type="";

    public ItemDetail(String vendorID)
    {
        venid=vendorID;
        frame.setTitle("Sell Item");

        label = new JLabel("Enter Item Details:");
        label.setForeground(Color.blue);
        label.setFont(new Font("Serif", Font.BOLD, 40));
        Font font=new Font("Serif",Font.BOLD,28);
        ImageIcon iconHome = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\homeIcon.png");
        homeButton= new JButton(iconHome);
        jewelleryRadioButton=new JRadioButton("Antique Jewellery");
        carsRadioButton=new JRadioButton("Vintage Cars");
        watchRadioButton=new JRadioButton("Antique Watches");
        yesButton=new JRadioButton("Yes");
        noButton=new JRadioButton("No");
        String date[] = {"1","2","3","4","5","6","7","8","9"};
       
        bg=new ButtonGroup();
        bg1=new ButtonGroup();
        
        label.setBounds(700,80,600,50);
        homeButton.setBounds(150, 150, 90, 40);
        jewelleryRadioButton.setBounds(350, 150, 250, 40);
        carsRadioButton.setBounds(600, 150, 250, 40);
        watchRadioButton.setBounds(850, 150, 250, 40);
        yesButton.setBounds(750, 500, 100, 40);
        noButton.setBounds(900, 500, 100, 40);

        homeButton.setFont(font);
        jewelleryRadioButton.setFont(font);
        carsRadioButton.setFont(font);
        watchRadioButton.setFont(font);
        bg.add(jewelleryRadioButton);
        bg.add(carsRadioButton);
        bg.add(watchRadioButton);
        bg1.add(yesButton);
        bg1.add(noButton);

        sourceLabel = new JLabel("");
        weightLabel = new JLabel("");
        ageLabel = new JLabel("");
        uploadPictureLabel = new JLabel("");
        l5 = new JLabel("");
        l6 = new JLabel("");

        l7 = new JLabel("Item Name");
        l8 = new JLabel("Start Date");
        l9 = new JLabel("End Date");
        l10 = new JLabel("Initial Amount");

        tf1 = new JTextField();
        tf2 = new JTextField();
        tf3 = new JTextField();
        //tf4 = new JTextField();
        tf5 = new JTextField();
        tf7 = new JTextField();
        tf8 = new JTextField();
        tf9 = new JTextField();
        tf10 = new JTextField();
       // tf11 = new JTextField();
        //tf12 = new JTextField();

        submitButton = new JButton("Submit");
        clearButton = new JButton("Clear");
        ImageIcon iconCalendar = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\calendar.png");
        startDateButton = new JButton(iconCalendar);
        endDateButton = new JButton(iconCalendar);
        ImageIcon iconUpload = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\upload.png");
        uploadPictureButton=new JButton(iconUpload);
        uploadDocumentButton = new JButton(iconUpload);
        
        submitButton.addActionListener(this);
        clearButton.addActionListener(this);
        
        startDateButton.addActionListener(this);
        endDateButton.addActionListener(this);
        uploadPictureButton.addActionListener(this);
        uploadDocumentButton.addActionListener(this);
        label.setBounds(700,80,600,50);

        sourceLabel.setBounds(550, 250, 400, 30);
        weightLabel.setBounds(550, 300, 300, 30);
        ageLabel.setBounds(550, 350, 300, 30);
        uploadPictureLabel.setBounds(550, 400, 300, 30);
        l5.setBounds(550, 450, 300, 30);
        l6.setBounds(500, 500, 300, 30);
        l7.setBounds(150, 250, 400, 30);
        l8.setBounds(150, 300, 300, 30);
        l9.setBounds(150, 350, 300, 30);
        l10.setBounds(150, 400, 300, 30);
        
        uploadDocumentButton.setBounds(750, 250, 200, 30);
        tf1.setBounds(750, 250, 200, 30);
        tf2.setBounds(750, 300, 200, 30);
        tf3.setBounds(750, 350, 200, 30);
        //tf4.setBounds(750, 400, 200, 30);
        tf5.setBounds(750, 450, 200, 30);
        tf7.setBounds(350, 250, 200, 30);
        tf8.setBounds(350, 300, 120, 30);
        tf9.setBounds(350, 350, 120, 30);
        tf10.setBounds(350, 400, 200, 30);
        startDateButton.setBounds(470, 300, 50, 30);
        endDateButton.setBounds(470, 350, 50, 30);
        uploadPictureButton.setBounds(750, 400, 200, 30);
        
        submitButton.setBounds(350, 550, 150, 40);
        clearButton.setBounds(650, 550, 100, 40);
        

        
        yesButton.setFont(font);
        noButton.setFont(font);
        sourceLabel.setFont(font);
        weightLabel.setFont(font);
        ageLabel.setFont(font);
        uploadPictureLabel.setFont(font);
        l5.setFont(font);
        l6.setFont(font);
        tf1.setFont(font);
        tf2.setFont(font);
        //tf4.setFont(font);
        tf5.setFont(font);
        l7.setFont(font);
        l8.setFont(font);
        l9.setFont(font);
        l10.setFont(font);
        tf3.setFont(font);
        tf7.setFont(font);
        tf8.setFont(font);
        tf9.setFont(font);
        tf10.setFont(font);
        startDateButton.setFont(font);
        endDateButton.setFont(font);
        uploadPictureButton.setFont(font);
        submitButton.setFont(font);
        clearButton.setFont(font);
        uploadDocumentButton.setFont(font);
        
        frame.add(uploadDocumentButton);
        frame.add(homeButton);
        frame.add(jewelleryRadioButton);
        frame.add(carsRadioButton);
        frame.add(watchRadioButton);
        frame.add(label);
        frame.add(sourceLabel);
        frame.add(weightLabel);
        frame.add(tf1);
        frame.add(ageLabel);
        frame.add(tf2);
        frame.add(uploadPictureLabel);
        frame.add(tf3);
        frame.add(l5);
        frame.add(l6);
        frame.add(tf5);
        frame.add(submitButton);
        frame.add(clearButton);
        frame.add(l7);
        frame.add(l8);
        frame.add(l9);
        frame.add(l10);
       
        frame.add(tf7);
        frame.add(tf8);
        frame.add(tf9);
        frame.add(tf10);
        frame.add(startDateButton);
        frame.add(endDateButton);
        frame.add(uploadPictureButton);
        frame.add(yesButton);
        frame.add(noButton);
        frame.add(uploadDocumentButton);
        homeButton.addActionListener(this);
        jewelleryRadioButton.addActionListener(this);
        carsRadioButton.addActionListener(this); 
        watchRadioButton.addActionListener(this);
        yesButton.addActionListener(this);
        noButton.addActionListener(this);
        
        
        yesButton.setVisible(false);
        noButton.setVisible(false);
        sourceLabel.setVisible(false);
        weightLabel.setVisible(false);
        ageLabel.setVisible(false);
        uploadPictureLabel.setVisible(false);
        l5.setVisible(false);
        l6.setVisible(false);
        tf1.setVisible(false);
        tf2.setVisible(false);
        tf3.setVisible(false);
        //tf4.setVisible(false);
        tf5.setVisible(false);
        l7.setVisible(false);
        l8.setVisible(false);
        l9.setVisible(false);
        l10.setVisible(false);
       
        tf7.setVisible(false);
        tf8.setVisible(false);
        tf9.setVisible(false);
        tf10.setVisible(false);
        startDateButton.setVisible(false);
        endDateButton.setVisible(false);
        submitButton.setVisible(false);
        uploadPictureButton.setVisible(false);
        clearButton.setVisible(false);
        uploadDocumentButton.setVisible(false);
        frame.setVisible(true);
        frame.setSize(2000, 2000);
        frame.setLayout(null);
    }

    public void actionPerformed(ActionEvent event)
    {
        if(event.getSource()==homeButton){
            new vendor(venid).setVisible(true);
            frame.setVisible(false);
        }
        else if(event.getSource()==jewelleryRadioButton)
        { x=1;
        type="antiquejewellery";
            l7.setVisible(true);
            l8.setVisible(true);
            l9.setVisible(true);
            l10.setVisible(true);
           
            tf7.setVisible(true);
            tf8.setVisible(true);
            tf9.setVisible(true);
            tf10.setVisible(true);
          
            sourceLabel.setText("Source");
            weightLabel.setText("Weight(in g)");
            uploadPictureLabel.setText("Upload Picture");
            ageLabel.setText("Approx Age");

            yesButton.setVisible(false);
            noButton.setVisible(false);    
            sourceLabel.setVisible(true);
            weightLabel.setVisible(true);
            ageLabel.setVisible(true);
            uploadPictureLabel.setVisible(true);
            l5.setVisible(false);
            l6.setVisible(false);
            tf1.setVisible(true);
            tf2.setVisible(true);
            tf3.setVisible(true);
            //tf4.setVisible(true);
            tf5.setVisible(false);
            submitButton.setVisible(true);
            clearButton.setVisible(true);
            startDateButton.setVisible(true);
            endDateButton.setVisible(true);
            uploadPictureButton.setVisible(true);
            uploadDocumentButton.setVisible(false);
        }

        else if(event.getSource()==carsRadioButton)
        {
            x=2;
            type="vintagecar";
            l7.setVisible(true);
            l8.setVisible(true);
            l9.setVisible(true);
            l10.setVisible(true);
           
            tf7.setVisible(true);
            tf8.setVisible(true);
            tf9.setVisible(true);
            tf10.setVisible(true);
            
            sourceLabel.setText("Upload Document");
            weightLabel.setText("Brand Name");
            ageLabel.setText("Model/Build");
            uploadPictureLabel.setText("Upload Picture");
            l5.setText("Approx Age:");
            l6.setText("Working Condition:");

            sourceLabel.setVisible(true);
            weightLabel.setVisible(true);
            ageLabel.setVisible(true);
            uploadPictureLabel.setVisible(true);
            l5.setVisible(true);
            l6.setVisible(true);

            tf1.setVisible(false);
            tf2.setVisible(true);
            tf3.setVisible(true);
            //tf4.setVisible(true);
            tf5.setVisible(true);
            yesButton.setVisible(true);
            noButton.setVisible(true);
            submitButton.setVisible(true);
            clearButton.setVisible(true);
            startDateButton.setVisible(true);
            endDateButton.setVisible(true);
            uploadPictureButton.setVisible(true);
            uploadDocumentButton.setVisible(true);
        }
        else if(event.getSource()==watchRadioButton)
        {
            x=3;
            type="antiquewatch";
              uploadDocumentButton.setVisible(false);
            l7.setVisible(true);
            l8.setVisible(true);
            l9.setVisible(true);
            l10.setVisible(true);
          
            tf7.setVisible(true);
            tf8.setVisible(true);
            tf9.setVisible(true);
            tf10.setVisible(true);
          
            sourceLabel.setText("Source");
            weightLabel.setText("Weight(in g)");
            ageLabel.setText("Brand Name");
            uploadPictureLabel.setText("Upload Picture");
            l5.setText("Approx Age:");
            l6.setText("Working Condition:");

            sourceLabel.setVisible(true);
            weightLabel.setVisible(true);
            ageLabel.setVisible(true);
            uploadPictureLabel.setVisible(true);
            l5.setVisible(true);
            l6.setVisible(true);

            tf1.setVisible(true);
            tf2.setVisible(true);
            //tf4.setVisible(true);
            tf5.setVisible(true);
            yesButton.setVisible(true);
            noButton.setVisible(true);
            tf3.setVisible(true);
            startDateButton.setVisible(true);
            endDateButton.setVisible(true);
            submitButton.setVisible(true);
            clearButton.setVisible(true);
            uploadPictureButton.setVisible(true);
        }

        else if (event.getSource() == submitButton)
        {
            s = tf8.getText(); s=s.trim();
                    s1 = s.substring(4);
                    s2 = s1.substring(0,3);
                    if(s2.equals("Jan")) s2="01";
                    else if(s2.equals("Feb")) s2="02";
                    else if(s2.equals("Mar")) s2="03";
                    else if(s2.equals("Apr")) s2="04";
                    else if(s2.equals("May")) s2="05";
                    else if(s2.equals("Jun")) s2="06";
                    else if(s2.equals("Jul")) s2="07";
                    else if(s2.equals("Aug")) s2="08";
                    else if(s2.equals("Sep")) s2="09";
                    else if(s2.equals("Oct")) s2="10";
                    else if(s2.equals("Nov")) s2="11";
                    else if(s2.equals("Dec")) s2="12";
                    System.out.println(s2);
                    s3 = s1.substring(4,6);System.out.println(s3);
                    int l1,l2;
                    l2 = s1.length(); l1 = s1.lastIndexOf(' ');s4=s1.substring(l1+1,l2);
                    s5 = s1.substring(7,15);
                    strtd = s4+"-"+s2+"-"+s3+" "+s5;
                    
                    s = tf9.getText(); s=s.trim();
                    s1 = s.substring(4);
                    s2 = s1.substring(0,3);
                    if(s2.equals("Jan")) s2="01";
                    else if(s2.equals("Feb")) s2="02";
                    else if(s2.equals("Mar")) s2="03";
                    else if(s2.equals("Apr")) s2="04";
                    else if(s2.equals("May")) s2="05";
                    else if(s2.equals("Jun")) s2="06";
                    else if(s2.equals("Jul")) s2="07";
                    else if(s2.equals("Aug")) s2="08";
                    else if(s2.equals("Sep")) s2="09";
                    else if(s2.equals("Oct")) s2="10";
                    else if(s2.equals("Nov")) s2="11";
                    else if(s2.equals("Dec")) s2="12";
                    System.out.println(s2);
                    s3 = s1.substring(4,6);System.out.println(s3);
                    
                    l2 = s1.length(); l1 = s1.lastIndexOf(' ');s4=s1.substring(l1+1,l2);
                    s5 = s1.substring(7,15);
                    endd = s4+"-"+s2+"-"+s3+" "+s5;
           try{
           if(tf7.getText().equals("")){
                 JOptionPane.showMessageDialog(null, "Fill all the required fields");
             }
            else{
                  itemid = "itemid"+first;
                  
                  itemnm = tf7.getText();
                  biddernm = "";
                  currbid = 0;
                  initamt = Integer.parseInt(tf10.getText());
                 Conn c1 = new Conn();
                 if(x==1)
                 {
                   source = tf1.getText();
                   age = Integer.parseInt(tf3.getText());
                   wt = Integer.parseInt(tf2.getText());
                 String q1 = "insert into antiquejewellery values('"+itemid+"','"+venid+"','"+itemnm+"','"+strtd+"','"+endd+"','"
                         +initamt+"','"+currbid+"','"+biddernm+"','"+source+"','"+wt+"','"+age+"','"+pic+"')";
                 c1.s.executeUpdate(q1);
                 }
                else if(x==2)
                {
                  age = Integer.parseInt(tf5.getText());
                   brand = tf2.getText();
                   model = tf3.getText();
                   
                    
                 workC= 1;
                 
                String q1 = "insert into vintagecar values('"+itemid+"','"+venid+"','"+itemnm+"','"+strtd+"','"+endd+"','"
                         +initamt+"','"+currbid+"','"+biddernm+"','"+brand+"','"+model+"','"+age+"','"+workC+"','"+pic+"','"+doc+"')";
                 c1.s.executeUpdate(q1);
                }
                else if(x==3)
                {
                     age = Integer.parseInt(tf5.getText());
                   brand = tf3.getText();
                   source = tf1.getText();
                    wt = Integer.parseInt(tf2.getText());
                 workC= 1;
                String q1 = "insert into antiquewatch values('"+itemid+"','"+venid+"','"+itemnm+"','"+strtd+"','"+endd+"','"+initamt+"','"+currbid+"','"
                         +biddernm+"','"+source+"','"+wt+"','"+brand+"','"+age+"','"+workC+"','"+pic+"')";
                 c1.s.executeUpdate(q1);
                }
                 new Login().setVisible(true);
                frame.setVisible(false);
                }
          }
        catch(Exception ex){ex.printStackTrace();}
         }
        else if(event.getSource() == clearButton)
        {
            tf1.setText("");
            tf2.setText("");
            tf3.setText("");
            //tf4.setText("");
            tf5.setText("");

            tf7.setText("");
            tf8.setText("");
            tf9.setText("");
            tf10.setText("");
          
         }
        else if(event.getSource() == startDateButton)
        {
           
           new DateNTime().commitTime();
        }
        
        else if(event.getSource() == endDateButton)
        {
             new DateTime().commitTime();
        }
        else if(event.getSource() == uploadPictureButton)
        {
        new MainAppFrame("picture").setVisible(true);
        }
        else if(event.getSource() == uploadDocumentButton)
        {
        new MainAppFrame("document").setVisible(true);
        }
    }
    public static void main(String args[])
    {
       new ItemDetail(args[0]);
    }
}



                                                          
