/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package auction;
import java.sql.*;
/**
 *
 * @author SHUBHAM SRIVASTAVA
 */
public class Conn {
    Connection c;
    Statement s;
    String query;
    public Conn(){
       try{
                 Class.forName("com.mysql.jdbc.Driver");
                 c=DriverManager.getConnection("jdbc:mysql://localhost:3306/auction?serverTimezone=UTC", "root", "");
                 s = c.createStatement();
                }   
             catch (Exception e) {  
                    System.out.println("Error in Conn Class");
                    System.out.println(e);
                }   
    }
    
}
