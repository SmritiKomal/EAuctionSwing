package auction;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class vendor extends JFrame implements ActionListener{
    JLabel label, labelImage, labelDetail;
    JButton myItemsButton,addNewItemButton,profileButton, itemsAuctionButton;
    JFrame frame;
    String vendorID="",userType="";
    HashMap<String, String> userDetails=new HashMap<>();

    public vendor(String id){
        
        vendorID=id;
        frame=new JFrame();
        frame.setTitle("Vendor Page");
        
        label = new JLabel("Vendor Page");
        
        label.setForeground(Color.blue);
        label.setFont(new Font("Serif", Font.BOLD, 40));
        Font font=new Font("Serif",Font.BOLD,28);
        
        labelImage = new JLabel("");
        labelDetail = new JLabel("");
        
        myItemsButton=new JButton("My Items");
        ImageIcon iconBiddingHammer = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\biddingHammer.png");
        addNewItemButton=new JButton(iconBiddingHammer);
        ImageIcon iconProfile = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\profileUser.png");
        profileButton=new JButton(iconProfile);
        itemsAuctionButton=new JButton("Items Up for Auction");
        
        addNewItemButton.addActionListener(this);
        myItemsButton.addActionListener(this);
        profileButton.addActionListener(this);
        itemsAuctionButton.addActionListener(this);
        
        frame.add(label);
        frame.add(myItemsButton);
        frame.add(addNewItemButton);
        frame.add(profileButton);
        frame.add(labelDetail);
        frame.add(labelImage);
        frame.add(itemsAuctionButton);
        
        frame.setSize(2000, 2000);
        frame.setLayout(null);
        frame.setVisible(true);
        
        myItemsButton.setVisible(true);
        addNewItemButton.setVisible(true);
        profileButton.setVisible(true);
        itemsAuctionButton.setVisible(true);
        labelImage.setVisible(false);
        labelDetail.setVisible(false);
        
        label.setBounds(700,80,600,50);
        labelImage.setBounds(700, 300, 300, 400);
        labelDetail.setBounds(700, 700, 150, 50);
        myItemsButton.setBounds(200,250,150,50);
        addNewItemButton.setBounds(200,400,150,50);
        profileButton.setBounds(200,550,150,50);
        itemsAuctionButton.setBounds(200,350,250,50);
    }
    
    @Override
    public void actionPerformed(ActionEvent event){
        
        if(event.getSource()== myItemsButton){
            myItemsDisplay(vendorID);
            //frame.setVisible(false);
        }
        else if(event.getSource()== addNewItemButton){
            new ItemDetail(vendorID).setVisible(true);
            frame.setVisible(false);
        }
        else if(event.getSource()== profileButton){
            
            new Profile(vendorID,"vendor").setVisible(true);
            frame.setVisible(false);
        }else if(event.getSource()== itemsAuctionButton){
            
            new ItemsAuction(vendorID).setVisible(true);
            frame.setVisible(false);
        }
    }
    
    public void myItemsDisplay(String id){
        String q="";
        ResultSet r;
        try{
        Conn c1 = new Conn();
        String path="";
        q ="select * from vintagecar where Ven_ID='"+id+"'";
        r=c1.s.executeQuery(q);
        while(r.next())
        {
         labelImage.setVisible(true);
         labelDetail.setVisible(true);
         path=r.getString(13);
         ImageIcon iconUpload = new ImageIcon("\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"");
         labelDetail.setText(r.getString(3));
         labelImage.setIcon(iconUpload);
         sleep(500);
        }
        q ="select * from antiquewatch where Ven_ID='"+id+"'";
        r=c1.s.executeQuery(q);
        while(r.next())
        {
         
         labelDetail.setVisible(true);
         labelImage.setVisible(true);
         path=r.getString(14);
         System.out.println("\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"");
         ImageIcon iconUpload = new ImageIcon("\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"");
         //iconUpload.setImage(image);
         labelDetail.setText(r.getString(3));
         labelImage.setIcon(iconUpload);
         
         sleep(500);
        }
        q ="select * from antiquejewellery where Ven_ID='"+id+"'";
        r=c1.s.executeQuery(q);
        while(r.next())
        {
         labelImage.setVisible(true);
         labelDetail.setVisible(true);
         path=r.getString(12);
         ImageIcon iconUpload = new ImageIcon("\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"");
          
        labelDetail.setText(r.getString(3));
         labelImage.setIcon(iconUpload);
         sleep(500);
        }
        }
    catch(Exception e)
    {
        System.out.println(e);
    }
    
    }
    
    public static void main(String args[]){
        new vendor(args[0]);
    }
}
