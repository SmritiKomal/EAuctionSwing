package auction;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


public class forgot extends JFrame implements ActionListener
{
    JLabel l1, l2, l3;
    JTextField tf1, tf2;
    JButton btn1,btn2,btn3;
    JFrame f;
    String str1,pass,str2;int k=0;
    public forgot()
    {
        f=new JFrame();
        Font font=new Font("Serif",Font.BOLD,28);

        l1 = new JLabel("User Authentication");
        l1.setForeground(Color.blue);
        l1.setFont(new Font("Serif", Font.BOLD, 40));

        l2 = new JLabel("Email-Id:");
        l3 = new JLabel("Aadhar Number:");
        tf1 = new JTextField();
        tf2 = new JTextField();
        btn1 = new JButton("Submit");
        btn2 = new JButton("Home");
        btn3 = new JButton("abc");
        l1.setBounds(700, 80, 600, 50);
        l2.setBounds(580, 220, 200, 30);
        l3.setBounds(500, 270, 200, 30);
        tf1.setBounds(800, 220, 200, 30);
        tf2.setBounds(800, 270, 200, 30);
        btn1.setBounds(650, 350, 150, 40);
        btn2.setBounds(850, 350, 150, 40);
        btn3.setBounds(900, 350, 150, 40);
        l2.setFont(font);
        l3.setFont(font);
        tf1.setFont(font);
        tf2.setFont(font);
        btn1.setFont(font);
        btn2.setFont(font);
        btn3.setFont(font);
        f.add(l1);
        f.add(l2);
        f.add(tf1);
        f.add(l3);
        f.add(tf2);
        f.add(btn1);
        f.add(btn2);
        f.add(btn3);
        f.setVisible(true);
        f.setSize(2000, 2000);
        f.setLayout(null);

        btn1.addActionListener(this);
        btn2.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == btn1)
        {
            str1 = tf1.getText();
            str2 = tf2.getText();
        
           try{
            Conn c1 = new Conn();
            String q1  = "select * from customer where Email = '"+str1+"' and Aadhar = '"+str2+"'";
                ResultSet rs1 = c1.s.executeQuery(q1);
                if(rs1.next()){
                    k=1;
                   pass = rs1.getString("PassWord");
                }
                 String q2  = "select * from vendor where Email = '"+str1+"' and Aadhar = '"+str2+"'";
                 ResultSet rs2 = c1.s.executeQuery(q2);
                 if(rs2.next()){
                     k=1;
                    
                    pass = rs2.getString("PassWord");
                   
                    }
                if(k==0){
                    JOptionPane.showMessageDialog(null, "Incorrect email or Aadhar");   
                    }
                }
            catch(Exception e1)
        {
              System.out.println("Error in login");
              System.out.println(e1);
        }
              JOptionPane.showMessageDialog(null, "Your Password: "+pass); 
        }
        else  if(e.getSource() == btn2)
        {
            new Login().setVisible(true);
            f.setVisible(false);               
        }
    }


    public static void main(String arr[])
    {
        new forgot();
    }
}

