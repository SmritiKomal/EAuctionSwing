package auction;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener
{
    JLabel loginLabel, emailLabel, passwordLabel;
    JTextField emailTextField;
    JButton submitButton,newUserButton,forgotPasswordButton,btn4;
    JPasswordField passwordTextField;
    JFrame frame;
    String email,password,id;
    String customer="CUSTOMER", vendor="VENDOR",notRegistered="NOT_REGISTERED", userType="";

    public Login()
    {
        frame=new JFrame();
        Font font=new Font("Serif",Font.BOLD,28);
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        loginLabel = new JLabel("Log In");
        loginLabel.setForeground(Color.blue);
        loginLabel.setFont(new Font("Serif", Font.BOLD, 40));

        emailLabel = new JLabel("Enter Email:");
        passwordLabel = new JLabel("Enter Password:");
        emailTextField = new JTextField();
        passwordTextField = new JPasswordField();
        submitButton = new JButton("Submit");
        newUserButton = new JButton("New User");
        forgotPasswordButton = new JButton("Forgot password");
        btn4 = new JButton("hello");
        loginLabel.setBounds(700, 80, 600, 50);
        emailLabel.setBounds(580, 220, 200, 30);
        passwordLabel.setBounds(580, 270, 200, 30);
        emailTextField.setBounds(800, 220, 200, 30);
        passwordTextField.setBounds(800, 270, 200, 30);
        submitButton.setBounds(700, 350, 150, 40);
        newUserButton.setBounds(580, 400, 200, 40);
        forgotPasswordButton.setBounds(900, 400, 250, 40);
        btn4.setBounds(580, 600, 150, 40);
        emailLabel.setFont(font);
        passwordLabel.setFont(font);
        emailTextField.setFont(font);
        passwordTextField.setFont(font);
        submitButton.setFont(font);
        newUserButton.setFont(font);
        forgotPasswordButton.setFont(font);
        btn4.setFont(font);
        frame.add(loginLabel);
        frame.add(emailLabel);
        frame.add(emailTextField);
        frame.add(passwordLabel);
        frame.add(passwordTextField);
        frame.add(submitButton);
        frame.add(newUserButton);
        frame.add(forgotPasswordButton);
        frame.add(btn4);
        frame.setVisible(true);
        frame.setSize(2000, 2000);
        frame.setLayout(null);

        submitButton.addActionListener(this);
        newUserButton.addActionListener(this);
        forgotPasswordButton.addActionListener(this);

    }

    public boolean isEmailIdPasswordValid(){
       
        ResultSet rs1;
        try{
            Conn c1 = new Conn();
            String q1  = "select CustID from customer where Email='"+email+"' and Password='"+password+"'";
            rs1 = c1.s.executeQuery(q1);
            if(rs1.next()){
                userType=customer;
                id=rs1.getString(1);
                setVisible(false);
                return true;
            }
            String q2  = "select VendID from vendor where Email='"+email+"' and Password='"+password+"'";
            rs1 = c1.s.executeQuery(q2);
            if(rs1.next()){
                userType=vendor;
                id=rs1.getString(1);
                setVisible(false);
                return true;
            }
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        return false;

    }

    public void actionPerformed(ActionEvent event)
    {
        email = emailTextField.getText();
        password = new String(passwordTextField.getPassword());
        try{
            
            //showData();
            if(event.getSource() == submitButton){ 
                if(isEmailIdPasswordValid()){
                    if(userType.equals(vendor)){
                        System.out.println("Welcome Vendor");
                        new vendor(id).setVisible(true);
                        frame.setVisible(false);
                    }
                    else if(userType.equals(customer)){
                        System.out.println("Welcome Customer");
                        new customer(id).setVisible(true);
                        frame.setVisible(false);
                    }
                }
                else{
                    JOptionPane.showMessageDialog(null, "Email Id or Password is incorrect");
                }
            }
            else if (event.getSource() == newUserButton){
                new Registration().setVisible(true);
                frame.setVisible(false);
            }
            else if(event.getSource() == forgotPasswordButton){
                 new forgot().setVisible(true);
                 frame.setVisible(false);
            }
        }
        catch(Exception e1)
        {
              System.out.println("Error in login");
              System.out.println(e1);
        }
    }

  /*  public void showData()
    {
        JFrame f1 = new JFrame();
        JLabel l, l0;
        
    }
*/
    public static void main(String arr[])
    {
        new Login();
    }
}

