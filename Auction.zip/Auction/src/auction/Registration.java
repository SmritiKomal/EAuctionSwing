package auction;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.regex.*;
import java.awt.Color;
import java.sql.ResultSet;
import javax.swing.border.LineBorder;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Registration extends JFrame implements ActionListener
{
JLabel label,nameLabel, ageLabel, genderLabel, aadharLabel, mobileLabel, emailLabel, passwordLabel, confirmPasswordLabel, deliveryAddressLabel, countryLabel, presentAddressLabel, panNumberLabel, panUploadLabel, aadharUploadLabel, referenceLabel;
JLabel informationLabel;
JTextField nameTextField, ageTextField, aadharTextField, mobileTextField, emailTextField, addressTextField, panTextField,referenceTextField;
JButton submitButton, clearButton, backButton, passwordHintButton, panCardUploadButton, aadharCardUploadButton;
JPasswordField createPasswordTextField, confirmPasswordTextField;
JComboBox genderComboBox;
JRadioButton vendorAccountButton,customerAccountButton;
ButtonGroup bg;
String name,gender,email,password,presentAddress,deliveryAddress,address,aadharNumber,panNumber,mobileNumber, reference="",a="",b="",g="";
int age;
String createPassword, confirmPassword;
static String  aadhar="", pan="";
static String userType="",vendor="vendor", customer="customer";
static String INPUT_TYPE_EMAIL="EMAIL", INPUT_TYPE_PASSWORD="PASSWORD",INPUT_TYPE_AADHAR="AADHAR",INPUT_TYPE_MOBILE="MOBILE",INPUT_TYPE_PAN="PAN";
public static String vendorID,customerID;

JFrame frame=new JFrame();

Random ran = new Random();
int first4 = (ran.nextInt() % 9000) + 1000;
int again4 = (ran.nextInt() % 9000) + 1000;
int first = Math.abs(first4);
int again = Math.abs(again4);


public Registration()
{
        frame.setTitle("Registration Form in Java");

        label = new JLabel("Registration Form");
        label.setForeground(Color.blue);
        label.setFont(new Font("Serif", Font.BOLD, 40));
        Font font=new Font("Serif",Font.BOLD,28);

        vendorAccountButton=new JRadioButton("Vendor Account");
        customerAccountButton=new JRadioButton("Customer Account");
        bg=new ButtonGroup();

        label.setBounds(700,80,600,50);
        vendorAccountButton.setBounds(550, 150, 250, 40);
        customerAccountButton.setBounds(850, 150, 250, 40);
        vendorAccountButton.setFont(font);
        customerAccountButton.setFont(font);
        bg.add(vendorAccountButton);
        bg.add(customerAccountButton);
        //bg.add(r3);

        nameLabel = new JLabel("Name:");
        ageLabel = new JLabel("Age:");
        genderLabel = new JLabel("Gender:");
        aadharLabel = new JLabel("Aadhar Number:");
        mobileLabel = new JLabel("Mobile:");
        emailLabel = new JLabel("Email-ID:");
        passwordLabel = new JLabel("Create Password:");
        confirmPasswordLabel = new JLabel("Confirm Password:");

        deliveryAddressLabel = new JLabel("Delivery Address:");
        presentAddressLabel = new JLabel("Present Address:");
        countryLabel = new JLabel("Country:    INDIA");
        panNumberLabel = new JLabel("Pan Number:");
        panUploadLabel = new JLabel("Pan Card Upload:");
        aadharUploadLabel = new JLabel("Aadhar Card Upload:");
        referenceLabel = new JLabel("Reference:");

        String informationText="Choose respective button if you want to Buy or Sell Items.You need to create separate accounts and login if you want to do both.";
        String informationFormatting = "<html><body style='width: %1spx'>%1s";
        String information=String.format(informationFormatting,500,informationText);
        informationLabel=new JLabel(information);
        

        nameTextField = new JTextField();
        ageTextField = new JTextField();
        createPasswordTextField = new JPasswordField();
        confirmPasswordTextField = new JPasswordField();
        aadharTextField = new JTextField();
        mobileTextField = new JTextField();
        emailTextField = new JTextField();
        addressTextField = new JTextField();
        panTextField = new JTextField();
        referenceTextField = new JTextField();

        String s[]={"Male","Female","Other"};
        genderComboBox=new JComboBox(s);

        submitButton = new JButton("Submit");
        clearButton = new JButton("Clear");
        ImageIcon iconBack = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\back.png");
        backButton = new JButton(iconBack);
        ImageIcon iconQuestion = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\question.png");
        passwordHintButton = new JButton(iconQuestion);
        ImageIcon iconUpload = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\upload.png");
        panCardUploadButton= new JButton(iconUpload);
        aadharCardUploadButton= new JButton(iconUpload);

        submitButton.addActionListener(this);
        clearButton.addActionListener(this);
        backButton.addActionListener(this);
        passwordHintButton.addActionListener(this);
        panCardUploadButton.addActionListener(this);
        aadharCardUploadButton.addActionListener(this);

        label.setBounds(700,80,600,50);
        
        informationLabel.setBounds(640, 250, 400, 30);
        nameLabel.setBounds(640, 250, 400, 30);
        ageLabel.setBounds(660, 300, 200, 30);
        genderLabel.setBounds(620, 350, 200, 30);
        aadharLabel.setBounds(575, 400, 200, 30);
        mobileLabel.setBounds(655, 450, 200, 30);
        emailLabel.setBounds(600, 500, 200, 30);
        passwordLabel.setBounds(515, 550, 300, 30);
        confirmPasswordLabel.setBounds(495, 600, 300, 30);
        deliveryAddressLabel.setBounds(495, 650, 300, 30);
        presentAddressLabel.setBounds(495, 650, 300, 30);
        countryLabel.setBounds(1000, 650, 600, 30);
        panNumberLabel.setBounds(1000, 250, 600, 30);
        panUploadLabel.setBounds(1000, 350, 600, 30);
        aadharUploadLabel.setBounds(1000, 450, 600, 30);
        referenceLabel.setBounds(1000, 550, 600, 30);

        nameTextField.setBounds(750, 250, 200, 30);
        ageTextField.setBounds(750, 300, 200, 30);
        genderComboBox.setBounds(750, 350, 200, 30);
        aadharTextField.setBounds(750, 400, 200, 30);
        mobileTextField.setBounds(750, 450, 200, 30);
        emailTextField.setBounds(750, 500, 200, 30);
        createPasswordTextField.setBounds(750, 550, 200, 30);
        passwordHintButton.setBounds(1000, 550, 50, 30);
        confirmPasswordTextField.setBounds(750, 600, 200, 30);
        addressTextField.setBounds(750, 650, 300, 80);
        panTextField.setBounds(1000, 300, 200, 30);
        referenceTextField.setBounds(1000, 600, 200, 30);
        submitButton.setBounds(150, 150, 150, 40);
        clearButton.setBounds(150, 250, 150, 40);
        backButton.setBounds(150, 350, 50, 40);
        panCardUploadButton.setBounds(1000, 400, 80, 30);
        aadharCardUploadButton.setBounds(1000, 500, 80, 30);
        
        
        informationLabel.setFont(font);
        vendorAccountButton.setFont(font);
        customerAccountButton.setFont(font);
        nameLabel.setFont(font);
        ageLabel.setFont(font);
        genderLabel.setFont(font);
        aadharLabel.setFont(font);
        mobileLabel.setFont(font);
        emailLabel.setFont(font);
        passwordLabel.setFont(font);
        confirmPasswordLabel.setFont(font);
        deliveryAddressLabel.setFont(font);
        presentAddressLabel.setFont(font);
        countryLabel.setFont(font);
        panNumberLabel.setFont(font);
        panUploadLabel.setFont(font);
        aadharUploadLabel.setFont(font);
        referenceLabel.setFont(font);
        nameTextField.setFont(font);
        ageTextField.setFont(font);
        genderComboBox.setFont(font);
        aadharTextField.setFont(font);
        mobileTextField.setFont(font);
        emailTextField.setFont(font);
        addressTextField.setFont(font);
        createPasswordTextField.setFont(font);
        confirmPasswordTextField.setFont(font);
        submitButton.setFont(font);
        clearButton.setFont(font);
        backButton.setFont(font);
        passwordHintButton.setFont(font);
        panTextField.setFont(font);
        panCardUploadButton.setFont(font);
        aadharCardUploadButton.setFont(font);
        referenceTextField.setFont(font);
        frame.add(panTextField);
        frame.add(panCardUploadButton);
        frame.add(aadharCardUploadButton);
        frame.add(referenceTextField);
        frame.add(vendorAccountButton);
        frame.add(customerAccountButton);
        frame.add(label);
        frame.add(nameLabel);
        frame.add(ageLabel);
        frame.add(nameTextField);
        frame.add(genderLabel);
        frame.add(ageTextField);
        frame.add(aadharLabel);
        frame.add(createPasswordTextField);
        frame.add(mobileLabel);
        frame.add(confirmPasswordTextField);
        frame.add(emailLabel);
        frame.add(mobileTextField);
        frame.add(aadharTextField);
        frame.add(passwordLabel);
        frame.add(emailTextField);
        frame.add(confirmPasswordLabel);
        frame.add(genderComboBox);
        frame.add(deliveryAddressLabel);
        frame.add(presentAddressLabel);
        frame.add(countryLabel);
        frame.add(addressTextField);
        frame.add(submitButton);
        frame.add(clearButton);
        frame.add(backButton);
        frame.add(passwordHintButton);
        frame.add(panNumberLabel);
        frame.add(panUploadLabel);
        frame.add(aadharUploadLabel);
        frame.add(referenceLabel);
        frame.add(informationLabel);
        
        
        passwordHintButton.setVisible(false);
        nameLabel.setVisible(false);
        ageLabel.setVisible(false);
        genderLabel.setVisible(false);
        aadharLabel.setVisible(false);
        mobileLabel.setVisible(false);
        emailLabel.setVisible(false);
        passwordLabel.setVisible(false);
        confirmPasswordLabel.setVisible(false);
        deliveryAddressLabel.setVisible(false);
        presentAddressLabel.setVisible(false);
        countryLabel.setVisible(false);
        panNumberLabel.setVisible(false);
        panUploadLabel.setVisible(false);
        aadharUploadLabel.setVisible(false);
        referenceLabel.setVisible(false);
        nameTextField.setVisible(false);
        ageTextField.setVisible(false);
        aadharTextField.setVisible(false);
        mobileTextField.setVisible(false);
        emailTextField.setVisible(false);
        addressTextField.setVisible(false);
        panTextField.setVisible(false);
        panCardUploadButton.setVisible(false);
        aadharCardUploadButton.setVisible(false);
        referenceTextField.setVisible(false);
        submitButton.setVisible(false);
        clearButton.setVisible(false);
        backButton.setVisible(true);
        genderComboBox.setVisible(false);
        createPasswordTextField.setVisible(false);
        confirmPasswordTextField.setVisible(false);
        vendorAccountButton.addActionListener(this);
        customerAccountButton.addActionListener(this); 
        panCardUploadButton.addActionListener(this);
        frame.setVisible(true);
        frame.setSize(2000, 2000);
        frame.setLayout(null);
}
public boolean isAgeValid(){
    if((ageTextField.getText()).equals("")){
        JOptionPane.showMessageDialog(null, "Age can't be empty!");
        return false;
    }
    else if(Integer.parseInt(ageTextField.getText())<18){
        JOptionPane.showMessageDialog(null, "Age must be greater than 18.");
        return false;
    }
    return true;
}
public boolean isInputValid(){
    String textFormatting = "<html><body style='width: %1spx'>%1s</body></html>";
    if(name.equals("")){
        JOptionPane.showMessageDialog(null, "Name can't be empty!");
        return false;
    }
    else if(!isAgeValid()){
        return false;
    }
    else if(!isInputStringValid(email, INPUT_TYPE_EMAIL)){
        JOptionPane.showMessageDialog(null, "EmailID empty or invalid!");
        return false;
    }
    else if(!isCreatePasswordEqualConfirmPassword()){
        JOptionPane.showMessageDialog(null, "Both the password values don't match!");
        return false;
    }

    else if(!isInputStringValid(confirmPassword, INPUT_TYPE_PASSWORD)){
        String text="Password empty or invalid! Click on  the '?' to see the rules!";
        String message=String.format(textFormatting,400,text);
        JOptionPane.showMessageDialog(null,message );
        return false;
    }
    
    else if(!isInputStringValid(String.valueOf(aadharNumber), INPUT_TYPE_AADHAR)){
        JOptionPane.showMessageDialog(null, "Aadhar Number empty or invalid!");
        return false;
    }
    else if(!isInputStringValid(String.valueOf(mobileNumber), INPUT_TYPE_MOBILE)){
        JOptionPane.showMessageDialog(null, "Mobile Number empty or invalid!");
        return false;
    }
    else if(!isInputStringValid(String.valueOf(panNumber), INPUT_TYPE_PAN)){
        JOptionPane.showMessageDialog(null, "Pan Number empty or invalid!");
        return false;
    }
    else
        return true;
    }

public void clearTextFields(){
    nameTextField.setText("");
    ageTextField.setText("");
    aadharTextField.setText("");
    addressTextField.setText("");
    createPasswordTextField.setText("");
    confirmPasswordTextField.setText("");
    mobileTextField.setText("");
    emailTextField.setText("");
    panTextField.setText("");
}

public void setVisibleElements(boolean value){
        
        nameLabel.setVisible(value);
        ageLabel.setVisible(value);
        genderLabel.setVisible(value);
        aadharLabel.setVisible(value);
        mobileLabel.setVisible(value);
        emailLabel.setVisible(value);
        countryLabel.setVisible(value);
        panNumberLabel.setVisible(value);
        panUploadLabel.setVisible(value);
        aadharUploadLabel.setVisible(value);
        
        
        passwordLabel.setVisible(value);
        confirmPasswordLabel.setVisible(value);
        
        panCardUploadButton.setVisible(value);
        aadharCardUploadButton.setVisible(value);
        
        nameTextField.setVisible(value);
        ageTextField.setVisible(value);
        aadharTextField.setVisible(value);
        mobileTextField.setVisible(value);
        emailTextField.setVisible(value);
        panTextField.setVisible(value);
        genderComboBox.setVisible(value);
        
        createPasswordTextField.setVisible(value);
        confirmPasswordTextField.setVisible(value);
        
        addressTextField.setVisible(value);
        
        passwordHintButton.setVisible(value);
}

public void actionPerformed(ActionEvent event)
{
    informationLabel.setVisible(false);
    if(event.getSource()==vendorAccountButton)
    {
        userType=vendor;
        setVisibleElements(true);
       
        panCardUploadButton.setVisible(true);
        aadharCardUploadButton.setVisible(true);
        referenceTextField.setVisible(true);
        
        presentAddressLabel.setVisible(true);
        deliveryAddressLabel.setVisible(false);
        
        addressTextField.setVisible(true);
        referenceLabel.setVisible(true);

        submitButton.setVisible(true);
        clearButton.setVisible(true);
    }
    
    if(event.getSource()==customerAccountButton)
    {
        setVisibleElements(true);
        userType=customer;

        panCardUploadButton.setVisible(true);
        aadharCardUploadButton.setVisible(true);
        referenceTextField.setVisible(false);
        presentAddressLabel.setVisible(false);
        deliveryAddressLabel.setVisible(true);
        
        addressTextField.setVisible(true);
        submitButton.setVisible(true);
        clearButton.setVisible(true);

        referenceLabel.setVisible(false);
    }
    else if(event.getSource() == backButton){
        new Login().setVisible(true);
    }
    else if (event.getSource() == submitButton)
    {     try{
                name = nameTextField.getText();
                createPassword= new String(createPasswordTextField.getPassword());
                confirmPassword= new String(confirmPasswordTextField.getPassword());
                
                email = emailTextField.getText();
                gender = (String)genderComboBox.getSelectedItem(); 
                address=addressTextField.getText();
                
                aadharNumber = aadharTextField.getText();
                panNumber = panTextField.getText();
                mobileNumber =mobileTextField.getText();
                
                
                if(!isInputValid()){
                    clearTextFields();
                }
                else if(isUserAlreadyRegistered(aadharNumber)){
                    JOptionPane.showMessageDialog(null, "User already registered, please Login.");
                    new Login().setVisible(true);
                    frame.setVisible(false);
                }
                
                else{
                    password = confirmPassword;
                    age = Integer.parseInt(ageTextField.getText());
                    String id="";
                    if(userType.equals(vendor)){
                        vendorID = "vend"+again;
                        id=vendorID;
                        reference=referenceTextField.getText();
                       
                        if(!reference.equals("") && !isReferenceValid(reference))
                            {
                            String messageFormatting = "<html><body style='width: %1spx'>%1s";
                            String messageText="Invalid Reference ID.Enter a valid VendorID of the person referring you.";
                            String message=String.format(messageFormatting,400,messageText);
                            JOptionPane.showMessageDialog(null,message);
                            referenceTextField.setText(""); 
                            clearTextFields();
                            }
                        else{
                            updateDatabase(userType,id,name,age,gender,aadharNumber,panNumber,mobileNumber,email,password,reference,address,aadhar,pan);
                            String welcomeMessage="Welcome "+name+"!. Your "+userType+" ID is "+id+".";
                            JOptionPane.showMessageDialog(null, welcomeMessage);
                            new Login().setVisible(true);
                            frame.setVisible(false);
                        }
                        }
                        
                    
                    else{
                        customerID = "cust"+first;
                        id=customerID;
                        updateDatabase(userType,id,name,age,gender,aadharNumber,panNumber,mobileNumber,email,password,g,address,aadhar,pan);
                        String welcomeMessage="Welcome "+name+"!. Your "+userType+" ID is "+id+".";
                        JOptionPane.showMessageDialog(null, welcomeMessage);
                        new Login().setVisible(true);
                        frame.setVisible(false);

                    }
                    
                }
            }
            catch(Exception ex){ex.printStackTrace();}
    }
    else if(event.getSource() == clearButton)
    {
                clearTextFields();
    }
    else if(event.getSource() == passwordHintButton)
    {
            showPasswordHintButtonDialogBox();
    }
    else if(event.getSource() == panCardUploadButton){
            new MainAppFrame("pan").setVisible(true);
            
    }
    else if(event.getSource() == aadharCardUploadButton){
            new MainAppFrame("aadhar").setVisible(true);
            
    }
}
boolean isReferenceValid(String reference){
    String q="";
    reference="'"+reference+"'";
    try{
        Conn c1 = new Conn();
        
        q ="select * from vendor where VendID="+reference;
        ResultSet r=c1.s.executeQuery(q);
         if(r.getFetchSize()==0)
    return false;
    }
    catch(Exception e)
    {
        System.out.println(e);
    }
    return true;
}
boolean isUserAlreadyRegistered(String aadharNumber){
    String q="";
    aadharNumber="'"+aadharNumber+"'";
    try{
        Conn c1 = new Conn();
        
        q ="select * from vendor where aadhar="+aadharNumber;
        ResultSet r=c1.s.executeQuery(q);
         if(r.getFetchSize()==0)
    return false;
    }
    catch(Exception e)
    {
        System.out.println(e);
    }
    return true;
}

boolean isCreatePasswordEqualConfirmPassword(){
      return createPassword.equals(confirmPassword);
}

static void showPasswordHintButtonDialogBox(){
     String rule1="Password must be atleast 8 to 32 characters.";
     String rule2="Password must have atleast 3 out of these 4 (uppercase, lowercase letters, numbers and special characters).";
     String rule3="Password must have no more than 2 equal characters in a row"; 
     String rulesFormatting = "<html><body style='width: %1spx'><ul><li>%1s</li><li>%1s</li><li>%1s</li></ul></body></html>";
     String rules=String.format(rulesFormatting,400,rule1,rule2,rule3);
     JOptionPane.showMessageDialog(
                    null, rules);
}

static void updateDatabase(String userType,String id,String name, int age, String gender, String aadharNumber, String panNumber, String mobileNumber, String email, String password,String ref, String address, String aadhar, String pan ){
    try{
    Conn c1 = new Conn();
    String q1="", vendorID, customerID, presentAddress,deliveryAddress;
    if(userType.equals(vendor)){
        vendorID=id;
        presentAddress=address;
        q1 = "insert into vendor values('"+vendorID+"','"+name+"','"+age+"','"+gender+"','"
                 + ""+email+"','"+password+"','"+presentAddress+"','"+aadhar+"','"+pan+"','"+aadharNumber+"','"+panNumber+"','"+ref+"','"+mobileNumber+"')";
        
    }
    else if(userType.equals(customer))
    {
        customerID=id;
        deliveryAddress=address;
       q1 = "insert into customer values('"+customerID+"','"+name+"','"+age+"','"+gender+"','"
                 + ""+email+"','"+password+"','"+deliveryAddress+"','"+aadhar+"','"+pan+"','"+aadharNumber+"','"+panNumber+"','"+mobileNumber+"')";
        
    }
    c1.s.executeUpdate(q1);
    }
    catch(Exception ex){
        ex.printStackTrace();
    }
}

static boolean isInputStringValid(String inputString, String inputType){
    String emailValidationRegex="^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    String passwordValidationRegex="^(?:(?=.*\\d)(?=.*[A-Z])(?=.*[a-z])|(?=.*\\d)(?=.*[^A-Za-z0-9])(?=.*[a-z])|(?=.*[^A-Za-z0-9])(?=.*[A-Z])(?=.*[a-z])|(?=.*\\d)(?=.*[A-Z])(?=.*[^A-Za-z0-9]))(?!.*(.)\\1{2,})[A-Za-z0-9!~<>,;:_=?*+#.\"&§%°()\\|\\[\\]\\-\\$\\^\\@\\/]{8,32}$";
    String aadharNumberValidationRegex="^[2-9]{1}[0-9]{3}\\s[0-9]{4}\\s[0-9]{4}$";
    String mobileNumberValidationRegex="^(\\+\\d{1,3}[- ]?)?\\d{10}$";
    String panNumberValidationRegex="[A-Z]{5}[0-9]{4}[A-Z]{1}";
    String validationRegex="";
     
    if(inputType.equals(INPUT_TYPE_EMAIL)){
        validationRegex=emailValidationRegex;
        
    }else if(inputType.equals(INPUT_TYPE_PASSWORD)){
        validationRegex=passwordValidationRegex;
    }
    else if(inputType.equals(INPUT_TYPE_AADHAR)){
        validationRegex=aadharNumberValidationRegex;
    }
    else if(inputType.equals(INPUT_TYPE_MOBILE)){
        validationRegex=mobileNumberValidationRegex;
    }
    else if(inputType.equals(INPUT_TYPE_PAN)){
        validationRegex=panNumberValidationRegex;
    }

    Pattern validationPattern=Pattern.compile(validationRegex);
    if(inputString.length()==0){
        return false;
    }else{
        return validationPattern.matcher(inputString).matches();
    }
}

public static void main(String args[]){
    new Registration();
}
}



                                                          
