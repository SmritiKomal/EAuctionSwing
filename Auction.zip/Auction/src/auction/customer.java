package auction;
import static auction.ItemDetail.itemid;
import static auction.ItemDetail.type;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class customer extends Canvas implements ActionListener{
    JLabel label,detail,labelImage, labelDetail;
    JButton buyItemButton,profileButton,cartButton,buy;
    JFrame frame;
    String customerID="",userType="";
    HashMap<String, String> userDetails=new HashMap<>();
    String itemid,type;
    public customer(String id){
        
        customerID=id;
        frame=new JFrame();
        frame.setTitle("Welcome Customer!");
        
        label = new JLabel("Welcome Customer!");
        
        label.setForeground(Color.blue);
        label.setFont(new Font("Serif", Font.BOLD, 40));
        Font font=new Font("Serif",Font.BOLD,28);
        detail=new JLabel("");
        labelImage = new JLabel("");
        labelDetail = new JLabel("");
        frame.add(labelImage);
        frame.add(labelDetail);
        
        labelImage.setVisible(false);
        labelDetail.setVisible(false);
        labelImage.setBounds(700, 300, 300, 400);
        labelDetail.setBounds(700, 700, 150, 50);
        
        ImageIcon iconBid = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\bidding.png");
        buyItemButton=new JButton(iconBid);
        ImageIcon iconProfile = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\profileUser.png");
        profileButton=new JButton(iconProfile);
        ImageIcon iconCart = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\shoppingCart.png");
        cartButton=new JButton(iconCart);
        buy = new JButton("BUY");
        buy.setVisible(false);
        cartButton.setVisible(false);
        buy.addActionListener(this);
        buyItemButton.addActionListener(this);
        profileButton.addActionListener(this);
        cartButton.addActionListener(this);
      
        frame.add(buy);
        frame.add(label);
        frame.add(buyItemButton);
        frame.add(profileButton);
        frame.add(cartButton);
        frame.add(detail);
        
        frame.setSize(2000, 2000);
        frame.setLayout(null);
        frame.setVisible(true);
        
        buyItemButton.setVisible(true);
        profileButton.setVisible(true);
        cartButton.setVisible(true);
        
        label.setBounds(700,80,600,50);
        buyItemButton.setBounds(200,300,150,50);
        profileButton.setBounds(200,450,150,50);
        buy.setBounds(700,600, 150, 50);
        cartButton.setBounds(900, 600, 150, 50);
        detail.setBounds(500, 300, 100, 50);
    }
    
    @Override
    public void actionPerformed(ActionEvent event){
        
        if(event.getSource()== buyItemButton){
            buyItem(customerID);
            //frame.setVisible(false);
        }
        else if(event.getSource()== profileButton){
            new Profile(customerID,"customer").setVisible(true);
            frame.setVisible(false);
        }
        else if(event.getSource()== cartButton){
            new MyCart(itemid,type,customerID).setVisible(true);
            frame.setVisible(false);
        }
        else if(event.getSource() == buy)
        {
          new DisplayItemDetails(itemid,type,customerID).setVisible(true);
        }
    }
    
     public void buyItem(String id)
    {
        buy.setVisible(true);
        cartButton.setVisible(true);
        detail.setText("");
        String q="";
        ResultSet r;
        try{
        Conn c1 = new Conn();
        String path="";
        q ="select * from vintagecar where (curdate()>=StartDate and curdate()<=EndDate)";
        r=c1.s.executeQuery(q);
        while(r.next())
        {
            type="vintagecar";
            itemid=r.getString(1);
         labelImage.setVisible(true);
         labelDetail.setVisible(true);
         path=r.getString(13);
         ImageIcon iconUpload = new ImageIcon("\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"");
         labelDetail.setText(r.getString(3));
         labelImage.setIcon(iconUpload);
         sleep(500);
        }
        q ="select * from antiquewatch where (curdate()>=StartDate and curdate()<=EndDate)";
        r=c1.s.executeQuery(q);
        while(r.next())
        {
            type="antiquewatch";
         itemid=r.getString(1);
         labelDetail.setVisible(true);
         labelImage.setVisible(true);
         path=r.getString(14);
         System.out.println("\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"");
         ImageIcon iconUpload = new ImageIcon("\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"");
         //iconUpload.setImage(image);
         labelDetail.setText(r.getString(3));
         labelImage.setIcon(iconUpload);
         
         sleep(500);
        }
        q ="select * from antiquejewellery where (curdate()>=StartDate and curdate()<=EndDate)";
        r=c1.s.executeQuery(q);
        while(r.next())
        {
            type="antiquejewellery";
            itemid=r.getString(1);
         labelImage.setVisible(true);
         labelDetail.setVisible(true);
         path=r.getString(12);
         ImageIcon iconUpload = new ImageIcon("\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"");
          
        labelDetail.setText(r.getString(3));
         labelImage.setIcon(iconUpload);
         sleep(500);
        }
        }
    catch(Exception e)
    {
        System.out.println(e);
    }
    }
     
    public static void main(String args[]){
        new vendor(args[0]);
    }
    
}