package auction;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.regex.*;
import java.awt.Color;
import java.sql.ResultSet;
import javax.swing.border.LineBorder;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Profile extends JFrame implements ActionListener
{
JLabel label,nameLabel, mobileLabel, emailLabel, passwordLabel, confirmPasswordLabel, AddressLabel, countryLabel, panNumberLabel, panUploadLabel, aadharUploadLabel, referenceLabel;
JLabel Name;
JTextField mobileTextField, emailTextField, addressTextField;
JButton submitButton, clearButton, nextButton, passwordHintButton, homeButton;
JPasswordField createPasswordTextField, confirmPasswordTextField;
JComboBox genderComboBox;
JRadioButton vendorAccountButton,customerAccountButton;
ButtonGroup bg;
String name,email,password,presentAddress,deliveryAddress,address,mobileNumber;
int age;
String createPassword, confirmPassword;
static String userType="",userID="";
static String INPUT_TYPE_EMAIL="EMAIL", INPUT_TYPE_PASSWORD="PASSWORD",INPUT_TYPE_AADHAR="AADHAR",INPUT_TYPE_MOBILE="MOBILE",INPUT_TYPE_PAN="PAN";
public static String vendorID,customerID;

JFrame frame=new JFrame();

Random ran = new Random();
int first4 = (ran.nextInt() % 9000) + 1000;
int again4 = (ran.nextInt() % 9000) + 1000;
int first = Math.abs(first4);
int again = Math.abs(again4);


public Profile(String id, String user)
{
    userID=id;
    userType=user;
        frame.setTitle("Personal Details");

        label = new JLabel("Personal Details");
        label.setForeground(Color.blue);
        label.setFont(new Font("Serif", Font.BOLD, 40));
        Font font=new Font("Serif",Font.BOLD,28);

        label.setBounds(700,80,600,50);
      
        nameLabel = new JLabel("Name:");
        mobileLabel = new JLabel("Mobile:");
        emailLabel = new JLabel("Email-ID:");
        passwordLabel = new JLabel("Create Password:");
        confirmPasswordLabel = new JLabel("Confirm Password:");

        AddressLabel = new JLabel("");
       
        Name = new JLabel("");
        createPasswordTextField = new JPasswordField();
        confirmPasswordTextField = new JPasswordField();
        mobileTextField = new JTextField();
        emailTextField = new JTextField();
        addressTextField = new JTextField();
        
        homeButton= new JButton("H");
        submitButton = new JButton("Submit");
        ImageIcon iconQuestion = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\question.png");
        passwordHintButton = new JButton(iconQuestion);
        submitButton.addActionListener(this);
        passwordHintButton.addActionListener(this);
        homeButton.addActionListener(this);
        label.setBounds(700,80,600,50);
        
        
        nameLabel.setBounds(640, 250, 400, 30);
        mobileLabel.setBounds(655, 450, 200, 30);
        emailLabel.setBounds(600, 500, 200, 30);
        passwordLabel.setBounds(515, 550, 300, 30);
        confirmPasswordLabel.setBounds(495, 600, 300, 30);
        AddressLabel.setBounds(495, 650, 300, 30);
        
        Name.setBounds(750, 250, 200, 30);
        mobileTextField.setBounds(750, 450, 200, 30);
        emailTextField.setBounds(750, 500, 200, 30);
        createPasswordTextField.setBounds(750, 550, 200, 30);
        passwordHintButton.setBounds(1000, 550, 50, 30);
        confirmPasswordTextField.setBounds(750, 600, 200, 30);
        addressTextField.setBounds(750, 650, 300, 80);
        submitButton.setBounds(150, 150, 150, 40);
        homeButton.setBounds(150, 250, 150, 40);

        
        nameLabel.setFont(font);
        mobileLabel.setFont(font);
        emailLabel.setFont(font);
        passwordLabel.setFont(font);
        confirmPasswordLabel.setFont(font);
        AddressLabel.setFont(font);
        Name.setFont(font);
        mobileTextField.setFont(font);
        emailTextField.setFont(font);
        addressTextField.setFont(font);
        createPasswordTextField.setFont(font);
        confirmPasswordTextField.setFont(font);
        submitButton.setFont(font);
        passwordHintButton.setFont(font);
        homeButton.setFont(font);
        
        frame.add(label);
        frame.add(nameLabel);
        frame.add(Name);
        frame.add(createPasswordTextField);
        frame.add(mobileLabel);
        frame.add(confirmPasswordTextField);
        frame.add(emailLabel);
        frame.add(mobileTextField);
        frame.add(passwordLabel);
        frame.add(emailTextField);
        frame.add(confirmPasswordLabel);
        frame.add(AddressLabel);
        frame.add(addressTextField);
        frame.add(submitButton);
        frame.add(passwordHintButton);
        frame.add(homeButton);
        
        
        passwordHintButton.setVisible(true);
        
        nameLabel.setVisible(true);
        mobileLabel.setVisible(true);
        emailLabel.setVisible(true);
        passwordLabel.setVisible(true);
        confirmPasswordLabel.setVisible(true);
        AddressLabel.setVisible(true);
        Name.setVisible(true);
        mobileTextField.setVisible(true);
        emailTextField.setVisible(true);
        addressTextField.setVisible(true);
        homeButton.setVisible(true);
        submitButton.setVisible(true);
        createPasswordTextField.setVisible(true);
        confirmPasswordTextField.setVisible(true);
        ResultSet r;
        String q;
        try{
        Conn c1 = new Conn();
        if(userType.equals("vendor"))
        {
        q="select Name,MobileNo,Email,PresentAddress from vendor where VendID='"+userID+"'";
        r = c1.s.executeQuery(q);
            if(r.next()){
        Name.setText(r.getString(1));
        mobileTextField.setText(r.getString(2));
        emailTextField.setText(r.getString(3));
        addressTextField.setText(r.getString(4));
        AddressLabel.setText("Present Address");
        }
        }
        else if(userType.equals("customer"))
        {
            
        q="select Name,MobileNo,Email,DeliveryAddress from customer where CustID='"+userID+"'";
        r = c1.s.executeQuery(q);
            if(r.next()){
        Name.setText(r.getString(1));
        mobileTextField.setText(r.getString(2));
        emailTextField.setText(r.getString(3));
        addressTextField.setText(r.getString(4));
        AddressLabel.setText("Delivery Address");
        }
        }
        }
        catch(Exception e)
        { System.out.println(e); }
        frame.setVisible(true);
        frame.setSize(2000, 2000);
        frame.setLayout(null);
}

public boolean isInputValid(){
    String textFormatting = "<html><body style='width: %1spx'>%1s</body></html>";
    if(name.equals("")){
        JOptionPane.showMessageDialog(null, "Name can't be empty!");
        return false;
    }
    else if(!isInputStringValid(email, INPUT_TYPE_EMAIL)){
        JOptionPane.showMessageDialog(null, "EmailID empty or invalid!");
        return false;
    }
    else if(!isCreatePasswordEqualConfirmPassword()){
        JOptionPane.showMessageDialog(null, "Both the password values don't match!");
        return false;
    }

    else if(!isInputStringValid(confirmPassword, INPUT_TYPE_PASSWORD)){
        String text="Password empty or invalid! Click on  the '?' to see the rules!";
        String message=String.format(textFormatting,400,text);
        JOptionPane.showMessageDialog(null,message );
        return false;
    }
    
    else if(!isInputStringValid(String.valueOf(mobileNumber), INPUT_TYPE_MOBILE)){
        JOptionPane.showMessageDialog(null, "Mobile Number empty or invalid!");
        return false;
    }
    else
        return true;
    }

public void actionPerformed(ActionEvent event)
{
    
     if (event.getSource() == submitButton)
        {     try{
                            Conn c1 = new Conn();
                            String q1="";
                name = Name.getText();
                createPassword= new String(createPasswordTextField.getPassword());
                confirmPassword= new String(confirmPasswordTextField.getPassword());
                
                email = emailTextField.getText();
                address=addressTextField.getText();
                
                mobileNumber =mobileTextField.getText();
                
                
                
                if(isInputValid()){
                    password = confirmPassword;
                    if(userType.equals("vendor"))
                        {    
                            q1="Update vendor set Email='"+email+"',Password='"+createPassword+"',PresentAddress='"+address+"',MobileNo='"+mobileNumber+" AS  Where VendID='"+userID+"'";
                        }
                    
                    else{
                       q1="Update customer set Email='"+email+"',Password='"+createPassword+"',PresentAddress='"+address+"',MobileNo='"+mobileNumber+" AS  Where CustID='"+userID+"'";
                    }
                     c1.s.executeUpdate(q1);
                     String welcomeMessage="Profile Updated";
                     JOptionPane.showMessageDialog(null, welcomeMessage);
                        new Login().setVisible(true);
                        frame.setVisible(false);
                }
            }
            catch(Exception ex){ex.printStackTrace();}
    }
    else if(event.getSource() == passwordHintButton)
    {
            showPasswordHintButtonDialogBox();
    }
}

boolean isCreatePasswordEqualConfirmPassword(){
      return createPassword.equals(confirmPassword);
}

static void showPasswordHintButtonDialogBox(){
     String rule1="Password must be atleast 8 to 32 characters.";
     String rule2="Password must have atleast 3 out of these 4 (uppercase, lowercase letters, numbers and special characters).";
     String rule3="Password must have no more than 2 equal characters in a row"; 
     String rulesFormatting = "<html><body style='width: %1spx'><ul><li>%1s</li><li>%1s</li><li>%1s</li></ul></body></html>";
     String rules=String.format(rulesFormatting,400,rule1,rule2,rule3);
     JOptionPane.showMessageDialog(
                    null, rules);
}

static boolean isInputStringValid(String inputString, String inputType){
    String emailValidationRegex="^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    String passwordValidationRegex="^(?:(?=.*\\d)(?=.*[A-Z])(?=.*[a-z])|(?=.*\\d)(?=.*[^A-Za-z0-9])(?=.*[a-z])|(?=.*[^A-Za-z0-9])(?=.*[A-Z])(?=.*[a-z])|(?=.*\\d)(?=.*[A-Z])(?=.*[^A-Za-z0-9]))(?!.*(.)\\1{2,})[A-Za-z0-9!~<>,;:_=?*+#.\"&§%°()\\|\\[\\]\\-\\$\\^\\@\\/]{8,32}$";
    String aadharNumberValidationRegex="^[2-9]{1}[0-9]{3}\\s[0-9]{4}\\s[0-9]{4}$";
    String mobileNumberValidationRegex="^(\\+\\d{1,3}[- ]?)?\\d{10}$";
    String panNumberValidationRegex="[A-Z]{5}[0-9]{4}[A-Z]{1}";
    String validationRegex="";
     
    if(inputType.equals(INPUT_TYPE_EMAIL)){
        validationRegex=emailValidationRegex;
        
    }else if(inputType.equals(INPUT_TYPE_PASSWORD)){
        validationRegex=passwordValidationRegex;
    }
    else if(inputType.equals(INPUT_TYPE_AADHAR)){
        validationRegex=aadharNumberValidationRegex;
    }
    else if(inputType.equals(INPUT_TYPE_MOBILE)){
        validationRegex=mobileNumberValidationRegex;
    }
    else if(inputType.equals(INPUT_TYPE_PAN)){
        validationRegex=panNumberValidationRegex;
    }

    Pattern validationPattern=Pattern.compile(validationRegex);
    if(inputString.length()==0){
        return false;
    }else{
        return validationPattern.matcher(inputString).matches();
    }
}

public static void main(String args[]){
    new Profile(args[0], args[1]);
}
}



                                                          
