package auction;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import auction.Registration;


public class MainAppFrame extends JFrame{
    JButton button ;
    int result;
    String path="";
    public MainAppFrame(String type){
    super("Set Picture Into A JLabel Using JFileChooser In Java");
    button = new JButton("Browse");
    button.setBounds(300,300,100,40);
    add(button);
    
    button.addActionListener(new ActionListener() {

        public void actionPerformed(ActionEvent e) {
        
          JFileChooser file = new JFileChooser();
          file.setCurrentDirectory(new File(System.getProperty("user.home")));
          //filter the files
          FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images","jpeg", "jpg","gif","png");
          file.addChoosableFileFilter(filter);
           result = file.showSaveDialog(null);
           //if the user click on save in Jfilechooser
          if(result == JFileChooser.APPROVE_OPTION){
              File selectedFile = file.getSelectedFile();
              path = selectedFile.getAbsolutePath();
              if(type=="pan")
                  Registration.pan=path;
              else if(type=="aadhar")
                  Registration.aadhar=path;
              else if(type == "picture")
                  ItemDetail.pic=path;
              else if(type == "document")
                  ItemDetail.doc=path;
          }
          else if(result == JFileChooser.CANCEL_OPTION){
              System.out.println("No File Select");
          }
        }
    });
    
    setLayout(null);
    //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setSize(700,400);
    setVisible(true);
    }
     
     
    
    public static void main(String[] args){
        new MainAppFrame(args[0]);
    }
   }