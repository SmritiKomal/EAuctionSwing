package auction;
import static auction.ItemDetail.itemid;
import static auction.ItemDetail.type;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.regex.*;
import java.awt.Color;
import java.sql.ResultSet;
import java.sql.*;
import javax.swing.border.LineBorder;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class DisplayItemDetails extends JFrame implements ActionListener{
    JLabel label, imageLabel, itemNameLabel, itemNameValueLabel, startDateLabel, startDateValueLabel, endDateLabel, endDateValueLabel, initialAmountLabel,initialAmountValueLabel ;
    JButton backButton, buyButton, addToCartButton,removeFromCartButton,bidButton, viewPictureButton;
    JFrame frame,smallFrame;
    JTextField bidPriceTextField;
   

    //Antique watch fields
    JLabel watchSourceLabel, watchSourceValueLabel, watchWeightLabel, watchWeightValueLabel, watchBrandLabel, watchBrandValueLabel, watchAgeLabel,watchAgeValueLabel, watchWorkingLabel, watchWorkingValueLabel; 

    //Vintage Car fields
    JLabel carViewDocumentLabel, carModelLabel,carModelValueLabel, carBrandLabel, carBrandValueLabel, carAgeLabel,carAgeValueLabel, carWorkingLabel, carWorkingValueLabel; 
    JButton carViewDocumentButton;

    //Antique jewellery fields
    JLabel jewellerySourceLabel, jewellerySourceValueLabel, jewelleryWeightLabel, jewelleryWeightValueLabel, jewelleryAgeLabel,jewelleryAgeValueLabel; 

              String name,startDate,endDate,initialAmount,watchSource,watchWeight,watchBrand,watchAge,watchWorking,carModel,carBrand,carAge,carWorking,jewellerySource,jewelleryWeight,jewelleryAge;
  static  String customerID="",item ="";
    HashMap<String, String> itemDetails=new HashMap<>();
    static String customer="customer", vendor="vendor", userType;
    static String vendorMyItems="vendorMyItems", customerMyCart="customerMyCart", customerAddItem="customerBuyItem", pageType;
    static String itemType, watch="watch",car="car", jewellery="jewellery";
    ResultSet rs1;
    int init=0;
    public DisplayItemDetails(String itemID,String itemType,String CustomerID){
        customerID=CustomerID;
        item = itemType;
        itemid=itemID;
       // System.out.println(item+" "+itemID);
        try{
            Conn c1 = new Conn();
            String q1  = "select * from "+item+" where itemID='"+itemid+"'";
             rs1 = c1.s.executeQuery(q1);
            if(rs1.next()){
              name=rs1.getString(3);
              startDate=rs1.getString(4);
              endDate=rs1.getString(5);
              initialAmount=rs1.getString(6);
              if(item=="antiquewatch")
              {
              //watch
               watchSource=rs1.getString(9);
               watchWeight=rs1.getString(10);
                watchBrand=rs1.getString(11);
                watchAge=rs1.getString(12);
                watchWorking=rs1.getString(13);
              }
              else if(item=="vintagecar")
              {
              carModel=rs1.getString(10);
        carBrand=rs1.getString(9);
         carAge=rs1.getString(11);
      carWorking=rs1.getString(12);
              }
              else if(item=="antiquejewellery")
              {
               jewellerySource=rs1.getString(9);
        jewelleryWeight=rs1.getString(10);
        jewelleryAge=rs1.getString(11);
              }
              System.out.println(jewellerySource+" "+jewelleryWeight+" "+jewelleryAge);
            }
             /*
        name="Titan Raga";
        startDate="12.2.11";
        endDate="13.2.11";  
        initialAmount="12200";
        watchSource="Store";
        watchWeight="12";
        watchBrand="Titan";
        watchAge="12";
        watchWorking="Yes";
        vendorID="123";
        userType=vendor;
        */
        }
         catch(Exception e)
                 {
                 
                 
                 }
         /*
        name="Titan Raga";
        startDate="12.2.11";
        endDate="13.2.11";  
        initialAmount="12200";
        watchSource="Store";
        watchWeight="12";
        watchBrand="Titan";
        watchAge="12";
        watchWorking="Yes";
        type="antiquewatch";
     //   vendorID="123";
        userType=vendor;
        */
        frame=new JFrame();
        
        frame.setTitle("ItemDetails");
        
        label = new JLabel("Item Details");
        
        label.setForeground(Color.blue);
        label.setFont(new Font("Serif", Font.BOLD, 40));
            

        Font font=new Font("Serif",Font.BOLD,28);
        
        itemNameLabel=new JLabel("Name :");
        itemNameValueLabel=new JLabel(name);
        startDateLabel=new JLabel("Start Date:");
        startDateValueLabel=new JLabel(startDate);
        endDateLabel=new JLabel("End Date:");
        endDateValueLabel=new JLabel(endDate);
        initialAmountLabel=new JLabel("Initial Amount:");
        initialAmountValueLabel=new JLabel(initialAmount);
        

        frame.add(label);
        frame.setSize(2000, 2000);  
        frame.setVisible(true); 
        frame.setLayout(null);
        label.setBounds(700,80,600,50);
        
        ImageIcon iconBack = new ImageIcon("C:\\Users\\USER\\Documents\\NetBeansProjects\\Auction\\src\\images\\back.png");
        backButton = new JButton(iconBack);

        buyButton = new JButton("BUY");

        ImageIcon iconAddToCart = new ImageIcon("C:\\Users\\SHUBHAM SRIVASTAVA\\Documents\\NetBeansProjects\\Auction\\src\\images\\addToCart.png");
        addToCartButton= new JButton(iconAddToCart);
        
        ImageIcon iconRemoveFromCart = new ImageIcon("C:\\Users\\SHUBHAM SRIVASTAVA\\Documents\\NetBeansProjects\\Auction\\src\\images\\removeFromCart.png");
        removeFromCartButton=new JButton(iconRemoveFromCart);

        viewPictureButton=new JButton("CLICK FOR IMAGE");

        

        buyButton.addActionListener(this);
        backButton.addActionListener(this);
        addToCartButton.addActionListener(this);
        removeFromCartButton.addActionListener(this);
        viewPictureButton.addActionListener(this);

        
        backButton.setBounds(150, 350, 50, 40);
        buyButton.setBounds(150, 450, 100, 50);
        addToCartButton.setBounds(150, 550, 100, 50);
        removeFromCartButton.setBounds(150, 550, 100, 50);

        viewPictureButton.setBounds(550, 150, 350, 40);
        itemNameLabel.setBounds(550, 250, 150, 50);
        itemNameValueLabel.setBounds(750, 250, 250, 50);
        startDateLabel.setBounds(550, 300, 250, 50);
        startDateValueLabel.setBounds(750, 300, 250, 50);
        endDateLabel.setBounds(550, 350, 250, 50);
        endDateValueLabel.setBounds(750, 350, 250, 50);
        initialAmountLabel.setBounds(550, 400, 250, 50);
        initialAmountValueLabel.setBounds(750, 400, 250, 50);



        backButton.setFont(font);
        buyButton.setFont(font);
        addToCartButton.setFont(font);
        removeFromCartButton.setFont(font);
        viewPictureButton.setFont(font);
        itemNameLabel.setFont(font);
        itemNameValueLabel.setFont(font);
        startDateLabel.setFont(font);
        startDateValueLabel.setFont(font);
        endDateLabel.setFont(font);
        endDateValueLabel.setFont(font);
        initialAmountLabel.setFont(font);
        initialAmountValueLabel.setFont(font);


        frame.add(backButton);
        frame.add(buyButton);
        frame.add(addToCartButton);
        frame.add(removeFromCartButton);

        frame.add(viewPictureButton);
        frame.add(itemNameLabel);
        frame.add(itemNameValueLabel);
        frame.add(startDateLabel);
        frame.add(startDateValueLabel);
        frame.add(endDateLabel);
        frame.add(endDateValueLabel);
        frame.add(initialAmountLabel);
        frame.add(initialAmountValueLabel);

        backButton.setVisible(true);
        if(pageType.equals(customerAddItem)){
            buyButton.setVisible(true);
            addToCartButton.setVisible(true);
            removeFromCartButton.setVisible(false);
        }
        else if(pageType.equals(customerMyCart)){
            buyButton.setVisible(true);
            addToCartButton.setVisible(false);
            removeFromCartButton.setVisible(true);
        }

        if(item.equals("antiquewatch")){
            watchSourceLabel=new JLabel("Source :");
            watchSourceValueLabel=new JLabel(watchSource);
            watchWeightLabel=new JLabel("Weight :");
            watchWeightValueLabel=new JLabel(watchWeight);
            watchBrandLabel=new JLabel("Brand:");
            watchBrandValueLabel=new JLabel(watchBrand);
            watchAgeLabel=new JLabel("Age:");
            watchAgeValueLabel=new JLabel(watchAge);
            watchWorkingLabel=new JLabel("Working :");
            watchWorkingValueLabel=new JLabel(watchWorking);

            watchSourceLabel.setBounds(550, 450, 250, 50);
            watchSourceValueLabel.setBounds(750, 450, 250, 50);
            watchWeightLabel.setBounds(550, 500, 250, 50);
            watchWeightValueLabel.setBounds(750, 500, 250, 50);
            watchBrandLabel.setBounds(550, 550, 250, 50);
            watchBrandValueLabel.setBounds(750, 550, 250, 50);
            watchAgeLabel.setBounds(550, 600, 250, 50);
            watchAgeValueLabel.setBounds(750, 600, 250, 50);
            watchWorkingLabel.setBounds(550, 650, 250, 50);
            watchWorkingValueLabel.setBounds(750, 650, 250, 50);

            watchSourceLabel.setFont(font);
            watchSourceValueLabel.setFont(font);
            watchWeightLabel.setFont(font);
            watchWeightValueLabel.setFont(font);
            watchBrandLabel.setFont(font);
            watchBrandValueLabel.setFont(font);
            watchAgeLabel.setFont(font);
            watchAgeValueLabel.setFont(font);
            watchWorkingLabel.setFont(font);
            watchWorkingValueLabel.setFont(font);
            
            frame.add(watchSourceLabel);
            frame.add(watchSourceValueLabel);
            frame.add(watchWeightLabel);
            frame.add(watchWeightValueLabel);
            frame.add(watchBrandLabel);
            frame.add(watchBrandValueLabel);
            frame.add(watchAgeLabel);
            frame.add(watchAgeValueLabel);
            frame.add(watchWorkingLabel);
            frame.add(watchWorkingValueLabel);


        }
        else if(item.equals("vintagecar")){
            carViewDocumentLabel=new JLabel("Document :");
            carViewDocumentButton=new JButton("VIEW DOCUMENT");
            carBrandLabel=new JLabel("Brand:");
            carBrandValueLabel=new JLabel(carBrand);
            carModelLabel=new JLabel("Model:");
            carModelValueLabel=new JLabel(carModel);
            carAgeLabel=new JLabel("Age:");
            carAgeValueLabel=new JLabel(watchAge);
            carWorkingLabel=new JLabel("Working :");
            carWorkingValueLabel=new JLabel(watchWorking);

            carViewDocumentButton.addActionListener(this);

            carViewDocumentLabel.setBounds(550, 450, 250, 50);
            carViewDocumentButton.setBounds(750, 450, 350, 50);
            carBrandLabel.setBounds(550, 500, 250, 50);
            carBrandValueLabel.setBounds(750, 500, 250, 50);
            carModelLabel.setBounds(550, 550, 250, 50);
            carModelValueLabel.setBounds(750, 550, 250, 50);
            carAgeLabel.setBounds(550, 600, 250, 50);
            carAgeValueLabel.setBounds(750, 600, 250, 50);
            carWorkingLabel.setBounds(550, 650, 250, 50);
            carWorkingValueLabel.setBounds(750, 650, 250, 50);

            carViewDocumentLabel.setFont(font);
            carViewDocumentButton.setFont(font);
            carBrandLabel.setFont(font);
            carBrandValueLabel.setFont(font);
            carModelLabel.setFont(font);
            carModelValueLabel.setFont(font);
            carAgeLabel.setFont(font);
            carAgeValueLabel.setFont(font);
            carWorkingLabel.setFont(font);
            carWorkingValueLabel.setFont(font);
            
            frame.add(carViewDocumentLabel);
            frame.add(carViewDocumentButton);
            frame.add(carBrandLabel);
            frame.add(carBrandValueLabel);
            frame.add(carModelLabel);
            frame.add(carModelValueLabel);
            frame.add(carAgeLabel);
            frame.add(carAgeValueLabel);
            frame.add(carWorkingLabel);
            frame.add(carWorkingValueLabel);


        }
        else if(item.equals("antiquejewellery")){
            jewellerySourceLabel=new JLabel("Source :");
            jewellerySourceValueLabel=new JLabel(jewellerySource);
            jewelleryWeightLabel=new JLabel("Weight :");
            jewelleryWeightValueLabel=new JLabel(jewelleryWeight);
            jewelleryAgeLabel=new JLabel("Age:");
            jewelleryAgeValueLabel=new JLabel(jewelleryAge);
            
            jewellerySourceLabel.setBounds(550, 450, 250, 50);
            jewellerySourceValueLabel.setBounds(750, 450, 250, 50);
            jewelleryWeightLabel.setBounds(550, 500, 250, 50);
            jewelleryWeightValueLabel.setBounds(750, 500, 250, 50);
            jewelleryAgeLabel.setBounds(550, 550, 250, 50);
            jewelleryAgeValueLabel.setBounds(750, 550, 250, 50);
           
            jewellerySourceLabel.setFont(font);
            jewellerySourceValueLabel.setFont(font);
            jewelleryWeightLabel.setFont(font);
            jewelleryWeightValueLabel.setFont(font);
            jewelleryAgeLabel.setFont(font);
            jewelleryAgeValueLabel.setFont(font);
            
            frame.add(jewellerySourceLabel);
            frame.add(jewellerySourceValueLabel);
            frame.add(jewelleryWeightLabel);
            frame.add(jewelleryWeightValueLabel);
            frame.add(jewelleryAgeLabel);
            frame.add(jewelleryAgeValueLabel);
        }
    }

    //TODO
    public void viewImage(String imagePath){
        JFrame imageFrame=new JFrame();
        imageFrame.setSize(600, 600);  
        imageFrame.setVisible(true); 
        imageFrame.setLayout(null);
        
        //TODO- get image path from DB
       
        try {
             String path=rs1.getString(13);
             path= "\""+path.substring(0,2)+ "\\\\" +path.substring(2,7)+ "\\\\" +path.substring(7,11)+ "\\\\" +path.substring(11,18)+ "\\\\" +path.substring(18,22)+ "\\\\" +path.substring(22)+"\"";
             BufferedImage image = ImageIO.read(new File(path));
             ImageIcon icon = new ImageIcon(image);
             imageLabel = new JLabel(icon);
             imageLabel.setBounds(0,0, 600, 600);
             imageFrame.add(imageLabel);
             imageLabel.setVisible(true);
            }
        catch (IOException e) {
                 e.printStackTrace();
        } catch (SQLException ex) {
            Logger.getLogger(DisplayItemDetails.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    @Override
    public void actionPerformed(ActionEvent event){
       
        if(event.getSource() == backButton){
        new customer("id").setVisible(true);
        }
        else if(event.getSource() == buyButton){
            showBidDialogBox();

        }else if(event.getSource() == addToCartButton){
            int inputDialogMessage = JOptionPane.showOptionDialog(null, "Add this item to your cart?", "Add to cart", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);

                if(inputDialogMessage == JOptionPane.OK_OPTION)
                {
                    addItemToCustomerCart();
                }
        }
        else if(event.getSource() == removeFromCartButton){
            
            int inputDialogMessage = JOptionPane.showOptionDialog(null, "Remove this item from your cart?", "Remove from cart", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);

                if(inputDialogMessage == JOptionPane.OK_OPTION)
                {
                    removeItemFromCustomerCart();
                }
            
        }
        else if(event.getSource() == bidButton){
            String bidPrice=bidPriceTextField.getText();
            if(validateBidPrice(bidPrice)){
                int inputDialogMessage = JOptionPane.showOptionDialog(null, "Place a bid for this item?", "Confirmation", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);

                if(inputDialogMessage == JOptionPane.OK_OPTION)
                {
                    int bidPriceValue=Integer.parseInt(bidPrice);
                
                    //TODO - if addition to db succesful, return true
                    if(storeBidPriceInVendorTable(bidPriceValue)){
                        //TODO- remove item when bid placed succesfully
                        removeItemFromCustomerCart();
                        JOptionPane.showMessageDialog(
                        null, "Succesfully placed a bid for the item.");
                        smallFrame.setVisible(false);
                    }
                    else{
                            JOptionPane.showMessageDialog(
                        null, "Error in placing bid please try later.");
                    
                    }
                    
                    
                }    
            }
        }
        else if(event.getSource() == viewPictureButton){
            //TODO send image path to viewImage
            viewImage("123");
        }
        else if(event.getSource() == carViewDocumentButton){
            //TODO send car document image path to viewImage
            viewImage("123");
        }
        
        
       
    }
    //TODO from db
    public void getItemDetails(){


    }

    public boolean validateBidPrice(String bidPrice){
        if(bidPrice.length()==0){
            JOptionPane.showMessageDialog(
                    null, "Empty bid price!");
            return false;
        }
        else{
            double bidPriceValue;
            try{
                bidPriceValue= Integer.parseInt(bidPrice);
                try{
   
                int a1=0,a2=0;
                Conn c1 = new Conn();

                String q1="",q2="";
                q1 = "select InitialAmount from "+item+" where ItemID='"+itemid+"'";

                ResultSet rs1 = c1.s.executeQuery(q1);
                        if(rs1.next()){
                           a1= Integer.parseInt(rs1.getString("InitialAmount"));
                        }
                q2 = "select CurrentBid from "+item+" where ItemID='"+itemid+"'";

                ResultSet rs2 = c1.s.executeQuery(q2);
                        if(rs2.next()){
                           a1= Integer.parseInt(rs2.getString("CurrentBid"));
                        }
                        init = (a1>a2)?a1:a2;
                
                    }
                catch(Exception ex){
                    ex.printStackTrace();
                }
                
                int initialAmount=init;
                if(bidPriceValue< initialAmount){
                    JOptionPane.showMessageDialog(
                    null, "Entered value less than initial amount!");
                    bidPriceTextField.setText("");
                    return false;
                }
                else{
                return true;
                }
            }catch(NumberFormatException nfe){
                JOptionPane.showMessageDialog(
                    null, "Enter only numeric values!");
                bidPriceTextField.setText("");    
                return false;
            }
            
        }
    }
    
    boolean storeBidPriceInVendorTable(int bidPriceValue){
    try{
   
    String Bn="";
    Conn c1 = new Conn();
   
    String q1="",q2="",q3="";
    q1 = "select Name from customer where CustID='"+customerID+"'";
  
    ResultSet rs1 = c1.s.executeQuery(q1);
            if(rs1.next()){
               Bn= rs1.getString("Name");
            }
    
    
    q2 = "update "+item+" set CurrentBid ='"+bidPriceValue+"' where ItemID = '"+itemid+"'";
    q3 = "update "+item+" set BidderName ='"+Bn+"' where ItemID = '"+itemid+"'";
    c1.s.executeUpdate(q2);
    c1.s.executeUpdate(q3);
    }
    catch(Exception ex){
        ex.printStackTrace();
    }
        return true;
    }
    public void showBidDialogBox(){
                
            smallFrame=new JFrame();
            smallFrame.setSize(600, 600);  
            smallFrame.setVisible(true); 
            smallFrame.setLayout(null);

            
            JLabel bidPriceLabel = new JLabel("Bid Price Rs.:");
            bidPriceTextField = new JTextField(); 
            bidButton = new JButton("BID");

            bidPriceLabel.setForeground(Color.blue);
            bidPriceLabel.setFont(new Font("Serif", Font.BOLD, 40));
            Font font=new Font("Serif",Font.BOLD,28);
                
            bidPriceLabel.setFont(font);
            bidPriceTextField.setFont(font);
            bidButton.setFont(font);

            
            bidPriceLabel.setBounds(100,100,250,50);
            bidPriceTextField.setBounds(400,100,150,50);
            bidButton.setBounds(300,300,90,50);
            
            bidButton.addActionListener(this);

            smallFrame.add(bidPriceLabel);
            smallFrame.add(bidPriceTextField);
            smallFrame.add(bidButton);
            
            bidPriceLabel.setVisible(true);
            bidPriceTextField.setVisible(true);
            bidButton.setVisible(true);
          
    }
    //TODO
    static void addItemToCustomerCart(){
     String q="";
        ResultSet r;
        try{
        Conn c1 = new Conn();
        
        
        q ="insert into cart values("+customerID+","+itemid+") ;";
        c1.s.executeQuery(q);
        }
        catch(Exception e){}
    }
    //TODO
    static void removeItemFromCustomerCart(){

    }

    //TODO- store itemdetails from the table in the declared hashmap itemDetails (line 21)
     public void getItemDetails(String itemType, String itemID)
    {
        String q="";
        ResultSet r;
        try{
        Conn c1 = new Conn();
        
        
        q ="select * from vintagecar where /date/ ";
        r=c1.s.executeQuery(q);
        //if(r.getFetchSize()==0)
        
        q ="select ItemID from antiquewatch where /date/ ";
        r=c1.s.executeQuery(q);
        //if(r.getFetchSize()==0)
        
        q ="select ItemID from antiquejewellery where /date/ ";
        r=c1.s.executeQuery(q);
        //if(r.getFetchSize()==0)
        
        
    }
        
    catch(Exception e)
    {
        System.out.println(e);
    }
    }
     
    public static void main(String args[]){
        new DisplayItemDetails(args[0],args[1],args[2]);
    }
}