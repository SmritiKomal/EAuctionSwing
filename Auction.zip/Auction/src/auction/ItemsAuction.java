package auction;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class ItemsAuction extends JFrame implements ActionListener{
    JLabel label, noItemMessageLabel, currentDateTimeLabel, itemNameLabel,itemNameValueLabel, finalBidLabel,finalBidValueLabel, bidderNameLabel, bidderNameValueLabel ;
    JButton viewItemDetailsButton;
    JFrame frame;
    String vendorID="",itemID="", itemName="", finalBid="", bidderName="";
    String currentDateAndTime="";
    
    public ItemsAuction(String vendorId){
        vendorID=vendorId;

        frame=new JFrame();
        frame.setTitle("Vendor Page");
        
        label = new JLabel("Items Ready to be Sold");
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime dateTime = LocalDateTime.now();
        currentDateAndTime = dateTime.format(formatter); // "1986-04-08 12:30:12"

        currentDateTimeLabel = new JLabel(currentDateAndTime);
        
        System.out.println("Date Time"+ currentDateAndTime);

        label.setForeground(Color.blue);
        label.setFont(new Font("Serif", Font.BOLD, 40));
        Font font=new Font("Serif",Font.BOLD,28);
        currentDateTimeLabel.setFont(font);

        frame.add(label);
        frame.add(currentDateTimeLabel);

        label.setBounds(500,80,600,50);
        currentDateTimeLabel.setBounds(600,200,600,50);
        frame.setSize(2000, 2000);
        frame.setLayout(null);
        frame.setVisible(true);
        
        itemNameLabel = new JLabel("Items Name:");
            itemNameValueLabel= new JLabel(itemName);
            finalBidLabel = new JLabel("Final Bid Price:");
            finalBidValueLabel= new JLabel(finalBid);
            bidderNameLabel= new JLabel("Bidder Name:");
            bidderNameValueLabel= new JLabel(bidderName);
           
            //   itemNameValueLabel.setText(itemName);
            //  finalBidValueLabel.setText(finalBid);
            //  bidderNameValueLabel.setText(bidderName);
            
        if(getItemWithCurrentEndDate()){
            /*will remove later
            itemName="Watch Raga";
            finalBid="1200";
            bidderName="Raju";
            */
               itemNameValueLabel.setText(itemName);
              finalBidValueLabel.setText(finalBid);
              bidderNameValueLabel.setText(bidderName);
            
            itemNameLabel.setBounds(550, 350, 250, 50);
            itemNameValueLabel.setBounds(750, 350, 250, 50);
            finalBidLabel.setBounds(550, 400, 250, 50);
            finalBidValueLabel.setBounds(750, 400, 250, 50);
            bidderNameLabel.setBounds(550, 550, 250, 50);
            bidderNameValueLabel.setBounds(750, 550, 250, 50);
            

            itemNameLabel.setFont(font);
            itemNameValueLabel.setFont(font);
            finalBidLabel.setFont(font);
            finalBidValueLabel.setFont(font);
            bidderNameLabel.setFont(font);
            bidderNameValueLabel.setFont(font);
            
            
            frame.add(itemNameLabel);
            frame.add(itemNameValueLabel);
            frame.add(finalBidLabel);
            frame.add(finalBidValueLabel);
            frame.add(bidderNameLabel);
            frame.add(bidderNameValueLabel);
            
        }
        else{
                noItemMessageLabel= new JLabel("No item with current date!");
                noItemMessageLabel.setBounds(550, 450, 350, 50);
                noItemMessageLabel.setFont(font);
                frame.add(noItemMessageLabel);
        }
        
        
    }
    @Override
    public void actionPerformed(ActionEvent event){
        System.out.println("actions");
    }

    public boolean getItemWithCurrentEndDate(){
        
        String query="";
        ResultSet resultSet;
        try{
        Conn connection = new Conn();
        String path="";
        
        String tableNames[]={"vintagecar", "antiquewatch","antiquejewellery"};
        for(int i=0;i<3;i++){
        String tableName=tableNames[i];
            query ="select ItemID, ItemName, CurrentBid, BidderName from '"+tableNames[i]+"' where Ven_ID='"+vendorID+"'"+ "AND EndDate>='"+currentDateAndTime+"'";
        resultSet=connection.s.executeQuery(query);
        
        if(resultSet.next()){
              itemID=resultSet.getString(1);
              itemName=resultSet.getString(2);
           //   itemNameValueLabel.setText(itemName);
            //  finalBidValueLabel.setText(finalBid);
            //  bidderNameValueLabel.setText(bidderName);
            
              finalBid=resultSet.getString(3);
             // finalBidValueLabel.setText(finalBid);
              
              bidderName=resultSet.getString(4);
            //  bidderNameValueLabel.setText(bidderName);
              return true;
        }
        }
    }
        catch(Exception e){}
         return true;
    }
    
    public static void main(String args[]){
        new ItemsAuction(args[0]);
    }
    
}
